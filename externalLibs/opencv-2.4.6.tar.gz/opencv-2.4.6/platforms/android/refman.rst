############################
OpenCV4Android Reference
############################

.. toctree::
   :maxdepth: 2

   service/doc/index.rst
   java.rst