#ifndef __TEGRA_DETECTOR_H__
#define __TEGRA_DETECTOR_H__

#define TEGRA_DETECTOR_ERROR -2
#define TEGRA_NOT_TEGRA -1

int DetectTegra();

#endif